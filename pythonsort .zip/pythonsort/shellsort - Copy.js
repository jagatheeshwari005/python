const barsContainer = document.getElementById("bars");
const speedInput = document.getElementById("speed");
const submitArrayButton = document.getElementById("submitArray");
const startSortButton = document.getElementById("startSort");
const userInput = document.getElementById("userInput");

let array = [];
let speed = 50; // Default speed

// Update speed dynamically
speedInput.addEventListener("input", () => {
    speed = 101 - speedInput.value; // Higher range means slower animation
});

// Render bars based on the array
function renderBars() {
    barsContainer.innerHTML = "";
    for (let value of array) {
        const bar = document.createElement("div");
        bar.classList.add("bar");
        bar.style.height = `${value * 3}px`;
        bar.style.width = "15px";
        barsContainer.appendChild(bar);
    }
}

// Parse user input and display bars
submitArrayButton.addEventListener("click", () => {
    const input = userInput.value.trim();
    if (!input) {
        alert("Please enter some numbers separated by commas.");
        return;
    }

    // Convert input into an array of numbers
    array = input.split(",").map(num => parseInt(num.trim(), 10));

    // Validate the array
    if (array.some(isNaN)) {
        alert("Invalid input. Please enter numbers separated by commas.");
        array = [];
        return;
    }

    renderBars();
});

// Visualize shell sort
async function shellSort() {
    const bars = document.getElementsByClassName("bar");
    let n = array.length;
    let gap = Math.floor(n / 2);

    while (gap > 0) {
        for (let i = gap; i < n; i++) {
            let temp = array[i];
            let j = i;

            bars[i].style.backgroundColor = "red";

            while (j >= gap && array[j - gap] > temp) {
                array[j] = array[j - gap];
                bars[j].style.height = `${array[j]}px`;
                bars[j].style.backgroundColor = "yellow";
                j -= gap;

                await new Promise(resolve => setTimeout(resolve, speed));

                bars[j].style.backgroundColor = "blue";
            }
            array[j] = temp;
            bars[j].style.height = `${temp}px`;
            bars[i].style.backgroundColor = "green";
        }
        gap = Math.floor(gap / 2);
    }

    // Mark all bars as sorted
    for (let bar of bars) {
        bar.style.backgroundColor = "green";
    }
}

// Start sorting on button click
startSortButton.addEventListener("click", () => {
    if (array.length === 0) {
        alert("Please submit an array first.");
        return;
    }
    shellSort();
});
