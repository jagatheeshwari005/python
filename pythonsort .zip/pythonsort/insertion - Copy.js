const barsContainer = document.getElementById("bars");
const userInput = document.getElementById("userInput");
const submitArrayButton = document.getElementById("submitArray");
const startSortButton = document.getElementById("startSort");

let array = [];

// Function to render bars based on the array
function renderBars() {
    barsContainer.innerHTML = "";
    for (let value of array) {
        const bar = document.createElement("div");
        bar.classList.add("bar");
        bar.style.height = `${value * 3}px`;
        bar.style.width = "20px";
        barsContainer.appendChild(bar);
    }
}

// Parse user input and display bars
submitArrayButton.addEventListener("click", () => {
    const input = userInput.value.trim();
    if (!input) {
        alert("Please enter some numbers.");
        return;
    }

    // Convert input into an array of numbers
    array = input.split(",").map(num => parseInt(num, 10));

    // Validate the array
    if (array.some(isNaN)) {
        alert("Invalid input. Please enter numbers separated by commas.");
        array = [];
        return;
    }

    renderBars();
});

// Perform insertion sort with visualization
async function insertionSort() {
    const bars = document.getElementsByClassName("bar");

    for (let i = 1; i < array.length; i++) {
        let key = array[i];
        let j = i - 1;

        bars[i].style.backgroundColor = "red";

        while (j >= 0 && array[j] > key) {
            array[j + 1] = array[j];
            bars[j + 1].style.height = `${array[j] * 3}px`;
            bars[j + 1].style.backgroundColor = "yellow";

            await new Promise(resolve => setTimeout(resolve, 300));

            bars[j + 1].style.backgroundColor = "blue";
            j--;
        }
        array[j + 1] = key;

        bars[j + 1].style.height = `${key * 3}px`;
        bars[i].style.backgroundColor = "green";
    }
}

// Start sorting on button click
startSortButton.addEventListener("click", () => {
    if (array.length === 0) {
        alert("Please submit an array first.");
        return;
    }
    insertionSort();
});
