# app.py
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/sort', methods=['POST'])
def sort():
    data = request.json
    arr = data['array']
    sorted_array, steps = bubble_sort(arr)
    return jsonify({'sorted_array': sorted_array, 'steps': steps})

def bubble_sort(arr):
    n = len(arr)
    steps = []
    for i in range(n):
        swapped = False
        for j in range(0, n-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]  # Swap
                swapped = True
                steps.append(arr.copy())  # Save the state after the swap
        if not swapped:
            break
    return arr, steps

if __name__ == '__main__':
    app.run(debug=True)
